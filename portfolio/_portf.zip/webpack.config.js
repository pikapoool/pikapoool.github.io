var webpack = require('webpack');
var ExtractTextPlugin = require('extract-text-webpack-plugin');
var HtmlWebpackPlugin = require('html-webpack-plugin');

var path = require('path');
var srcDir = path.resolve(__dirname, 'src');
var distDir = path.resolve(__dirname, 'dist');
var postCssSource = srcDir + './postcss.config.js';
var htmlSource = path.resolve(__dirname, './src/index.html');

var isProduction = process.env.NODE_ENV === 'production';

module.exports = {
  context: srcDir,
  entry: 'main',
  resolve: {
    modules: [srcDir, 'node_modules'],
    extensions: ['.js'],
  },
  output: {
    path: distDir,
    filename: './build/bundle.js',
    // publicPath: './'
  },
  devtool: isProduction ? 'source-map' : 'eval-source-map',
  module: {
    rules: [
      // JS processed with babel
      {
        test: /\.js$|\.jsx$/,
        include: srcDir,
        exclude: /node_modules/,
        use: [{
        	loader: "react-hot-loader/webpack",
        	options: {
	          cacheDirectory: true,
	          presets: ['es2015', 'stage-2'],
        	}
        }, {
        	loader: "babel-loader",
        	options: {
	          cacheDirectory: true,
	          presets: ['es2015', 'stage-2'],
        	}
        }]
      },
      //CSS, extracted into single file in production mode
      {
        test: /\.css$/,
        use: ExtractTextPlugin.extract({
          fallback: "style-loader",
          use: [{
            loader: "css-loader",
            options: {
              sourceMap: true,
              minimize: isProduction
            }
          }, {
            loader: "postcss-loader",
            options: {
              sourceMap: true,
              config: {
                path: postCssSource
              }
            }
          }]
        })
      },
      //SCSS, extracted into single file in production mode
      {
        test: /\.scss$|\.sass$/,
        include: srcDir,
        use: ExtractTextPlugin.extract({
          fallback: "style-loader",
          use: [{
            loader: "css-loader",
            options: {
              sourceMap: true,
              minimize: isProduction
            }
          }, {
            loader: "postcss-loader",
            options: {
              sourceMap: true,
              config: {
                path: postCssSource
              }
            }
          }, {
            loader: "sass-loader",
            options: {
              sourceMap: true
            }
          }]
        })
      }
    ]
  },
  plugins: [
    new ExtractTextPlugin({
      filename: '../dist/css/[name].css',
      allChunks: true,
      disable: !isProduction
    }),
    new webpack.optimize.UglifyJsPlugin({
      compress: isProduction,
      beautify: !isProduction,
      sourceMap: true
    }),
    new HtmlWebpackPlugin({
      template: htmlSource
    })
  ],
  bail: isProduction
};
