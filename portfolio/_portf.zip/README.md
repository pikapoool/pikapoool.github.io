# myproject
experimental project

To run the project you need:

1) Install all dependencies: ```npm i```
2) Run webpack dev-server: ```npm run dev```

Project will automatically be open in your browser on ```http://localhost:8090```

You can check example in gitub page - [link](http://pikapoool.github.io/portfolio/myproject)
