import React from 'react';
import './WidItem.css';

const WidItem = ({icon, title, description}) =>
	<div className="col-sm-4 col-xs-12 wid-item">
		<div className="wid-icon">
			<img alt='' className="wid-img" src={icon} />
		</div>
		<div className="wid-title">{title}</div>
		<div className="wid-description" dangerouslySetInnerHTML={{__html: description}}></div>
	</div>

export default WidItem;
