import React from 'react';

import './PortfolioItem.css';

const PortfolioItem = ({ title, description, link, pages, preview, galerylayoutFirst, galerylayout, rel, backgroundColor }) =>
	<div className="portfolio_item">
		<div className="hover_overlay_rotate element">
			<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%">
				<line className="top" x1="0" y1="0" x2="900" y2="0"></line>
				<line className="left" x1="0" y1="300" x2="0" y2="-900"></line>
				<line className="bottom" x1="300" y1="300" x2="-600" y2="300"></line>
				<line className="right" x1="300" y1="0" x2="300" y2="900"></line>
			</svg>
			<div className="portfolio_item-top">
				{
					link
					?
					<a className="portfolio_item-websiteLinks" href={link}  target="_blank">
						<span className="portfolio_item-websiteLinks-cell">
							<span className="portfolio_item-websiteLinks-text">Visit the website</span>
						</span>
					</a>
					:
					pages.map((item,i) =>
						<a key={i} className="portfolio_item-websiteLinks" href={item}  target="_blank">
							<span className="portfolio_item-websiteLinks-cell">
								<span className="portfolio_item-websiteLinks-text">Page {i+1}</span>
							</span>
						</a>
					)
				}
			</div>
			<div className="hover_overlay_rotate_inner">
				<div className="element__inner">
					<img alt="" src={preview} className="element__img" data-evernote-hover-show="true" />
					<div className="element__overlay">
						<i className="element__overlay__bg element__overlay__bg_1"></i>
						<i className="element__overlay__bg element__overlay__bg_2"></i>
						<div className="element__overlay__inner element__overlay__inner_top" style={{backgroundColor: backgroundColor}}>
							<h3 className="element__overlay__title">{title}</h3>
							<p className="element__overlay__teaser" dangerouslySetInnerHTML={{__html: description}}></p>
						</div>
					</div>
				</div>
			</div>
			{galerylayout.length > 0 &&
				<div className="portfolio_item-bottom">
					<a href={galerylayoutFirst} rel={rel} className="fancybox portfolio_item-galleryLinks">
						<span className="portfolio_item-galleryLinks-cell">
							<span className="portfolio_item-galleryLinks-text">View the gallery layouts</span>
						</span>
					</a>
					{
						galerylayout.map((item,i) =>
							<a key={i} href={item} rel={rel} className="fancybox hidden"></a>
						)
					}
				</div>}
		</div>
	</div>


export default PortfolioItem;