import React, { Component } from 'react';
import PortfolioItem from '../PortfolioItem/PortfolioItem.jsx'
import FirstScreen from '../FirstScreen/FirstScreen.jsx'
import WidItem from '../WidItem/WidItem.jsx'
import data from '../../data.json'

import darkBaseTheme from 'material-ui/styles/baseThemes/darkBaseTheme';
import getMuiTheme from 'material-ui/styles/getMuiTheme';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import Checkbox from 'material-ui/Checkbox';
import { RadioButton, RadioButtonGroup } from 'material-ui/RadioButton';

import './App.css';

const wid = [
	{
		icon: './img/react.png',
		title: 'React',
		description: 'developing SPA using <a target="_blank" href="https://reactjs.org/">ReactJS</a> famework, <a target="_blank" href="https://redux.js.org/">Redux</a> for managing application state, <a target="_blank" href="https://facebook.github.io/jest/">Jest</a> for unit tests'
	},
	{
		icon: './img/angular.png',
		title: 'Angular 2+',
		description: 'developing SPA using <a target="_blank" href="https://angular.io/">Angular</a> famework, <a target="_blank" href="http://reactivex.io/rxjs/">RxJS</a>, <a target="_blank" href="https://jasmine.github.io/">Jasmine</a> for unit tests, <a target="_blank" href="https://nestjs.com/">NestJS</a> for backend'
	},
	{
		icon: './img/web.png',
		title: 'HTML5+CSS3+JS',
		description: 'develop web sites using <a target="_blank" href="https://jquery.com/">jQuery</a> and many different libraries'
	},
]

const getFrameworks = (key, data) => {
	return data.reduce((acc, item) => {
		if (!acc.includes(item[key])) {
			return [...acc, item[key]];
		}
		return acc;
	}, []);
}

export default class App extends Component {
	constructor(){
		super();
		this.state = {
			env: 'all'
		}
	}

	handleChangeRadio(e, value){
		this.setState({ env: value });
	}

	render() {
		return (
			<MuiThemeProvider muiTheme={getMuiTheme(darkBaseTheme)}>
				<div>
					<FirstScreen />
					<div className="container">
						<div className="row">
							<div className="col-xs-12">
								<div className="wid-head">What I do</div>
							</div>
						</div>
					</div>
					<div className="container">
						<div className="row wid-items">
							{
								wid.map( (item,i) =>
									<WidItem
										key={i}
										icon={item.icon}
										title={item.title}
										description={item.description}
									/>
								)
							}
						</div>
					</div>
					<div className="portfolio-title">you can check examples of my work below:</div>
					<div className="container">
						<div className="row">
							<div className="col-xs-12">
								<RadioButtonGroup className='portfolio-radiobuttons' name="frameworks" defaultSelected="all" onChange={this.handleChangeRadio.bind(this)}>
									<RadioButton
										value="all"
										label="All"
										style={{maxWidth: 80, display: "inline-block"}}
									/>
									{
										getFrameworks('env', data).map((item, i) =>
											<RadioButton
												key={i}
												value={item}
												label={item}
												style={{maxWidth: 130, display: "inline-block"}}
											/>
										)
									}
								</RadioButtonGroup>
							</div>
						</div>
					</div>
					<div className="container portfolio">
						<div className="row portfolio_items">
							{
								data
									.filter((item) => {
											if(this.state.env === 'all'){
												return true;
											}else{
												return this.state.env === item.env;
											}
										})
									.map( (item, i) =>
										<PortfolioItem
											key={i}
											title={item.title}
											description={item.description}
											link={item.link}
											pages={item.pages}
											preview={item.preview}
											backgroundColor={item.backgroundColor}
											galerylayoutFirst={item.galerylayoutFirst}
											galerylayout={item.galerylayout}
											rel={item.rel}
										/>
									)
							}
						</div>
					</div>
				</div>
			</MuiThemeProvider>
		);
	}
}
