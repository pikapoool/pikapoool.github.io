import React from 'react';
import Particles from 'react-particles-js';
import params from './params.json'

import './FirstScreen.css';

const FirstScreen = (props) =>
	<div className="container firstscreen">
		<Particles
			className="particles"
			params={params}
			style={{
			  width: '100%',
			  height: '100%',
			}}
		/>
		<div className="row">
			<div className="col-xs-12">
				<div className="firstscreen-title">
					<p className="firstscreen-text_top">HELLO, I AM ILCHENKO ALEKSANDR</p>
					<div className="firstscreen-text">I'm a Javascript developer</div>
				</div>
			</div>
		</div>
	</div>

export default FirstScreen;
