// import 'babel-polyfill';
import ReactDOM from 'react-dom';
import React from 'react';

import App from './components/App/App.jsx';

import './main.css';


ReactDOM.render(
	<App />,
	document.getElementById('app')
);

